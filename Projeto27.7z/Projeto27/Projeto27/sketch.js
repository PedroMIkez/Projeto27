
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

let engine;
let world;
var ball;
var ground;
var wedge;
var angle=60;
var poly;
var boxes=[];


function setup() {
  createCanvas(700,500);

  engine = Engine.create();
  world = engine.world;
  var option={
    isStatic:true
  };

  ground=Bodies.rectangle(100,300,400,10,option);
  World.add(world,ground);

  ground1=Bodies.rectangle(500,300,600,10,option);
  World.add(world,ground1);
  //box1 = new Box(200,100,50,50);
  

  rectMode(CENTER);
  ellipseMode(RADIUS);
}
function mousePressed(){
  boxes.push(
    
    //new Box(50,50,50,50)
    
    new Box(mouseX,mouseY,50,50)

    //new Box(50,50,mouseX,mouseY)
    
    //new Box(mouseY,mouseX,50,50)  
    
    )
}

function draw() 
{
  background(51);
  rect(ground.position.x,ground.position.y,400,10);
  rect(ground1.position.x,ground1.position.y,400,10)
  Engine.update(engine);
 for(var i=0;i<boxes.length;i++) {
 boxes[i].show();}
  
  
}

